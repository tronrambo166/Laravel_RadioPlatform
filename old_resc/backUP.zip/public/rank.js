

var arr = ["Fally ipupa","Radio & Weasel","P-Square feat. Don Jazzy","Mose Fanfan","Fally ipupa","Mercy Masika","Madilu System","Koffi Olomidé","DaVido","Luciano","Kanda Bongo Man","Franco","Franco","DJ Afrobeat","Oliver Mtukudzi","Sauti Sol","Alikiba","Aryon","Gramps Morgan","Buju Banton","Wailing Souls","Bob Marley & The Wailers","Don Carlos and Gold","Burning Spear","Peter Tosh","George Nooks","Richie Spice","Culture","Sanchez","Terry Linen","Archie Wonder","Jah Cure","Busy Signal","Romain Virgo","Junior Reid","Shaggy","Glen Washington","Ginjah","Lucky Dube","Bushman","Chronixx","Turbulence","Protoje","UB40","Franco","Rich Mavoko","Rose Muhando","Kanda Bongo Man","Diamond"," Davido","Tekno","Daddy Owen","Pépé Kallé","Busy Signal","Franco Et Le T.P. O.K. Jazz","Alice Kamande","Koffi Olomidé","Culture","Alikiba","Papa Wemba","Korede Bello","Madilu System","Reuben Kigame","Gloria Muliro","Extra Musica","The Animal(ost)","The Martins","Reuben Kigame","Ehab Hamed","All Gods' Die","Solly Mahlangu","M.O.G","Bony Mwaitege","Mercy Masika","Jemmimah Thiong'o","Angela Chibalonza Muliri","Jemmimah Thiong'o","Rose Muhando","Morgan Heritage","Madilu System","Koffi Olomidé","Tony Nyandundo","Koffi Olomidé","Beres Hammond","Koffi Olomidé","Jemmimah Thiong'o","Papa Cidy","Glen Washington","2face","Christina Shusho","Alaine","King Kaka","Konshens","Daddy Owen","Wenge Musica Maison Mère","Wayne Wonder","ferre Gola","Klimax Skimz","Wyre","Vanessa Mdee","Sanaipei Tande","Lucky Dube","Sauti Sol","Upendo Knone","AY","Elani","Bob Marley & The Wailers","Size 8 Reborn","Juliani","Tabu Ley Signeur Rochereau","Jemmimah Thiong'o","Rita Marley","P-Square feat. Awilo","Magic System","Lady Jaydee","Culture","Lucky Dube","Christina Shusho","Richie Spice","Flavour","Eunice Njeri","Franco","Rose Muhando","Kigoma All Stars","Franco","Modest Morgan","Nyota Ndogo","Simba Wanyika","H_art the Band","Conrad Sewell","Madilu System","Diamond","Racheal Magoola","Mbilia Bel","Geraldine Oduor","Solomon Mukubwa","Sanchez","Madilu System","Glen Washington","Freddie Mcgregor","Simaro Massiya Lutumba","Alpha Blondy & The Wailers","Tony Nyandundo","Aurlus Mabele","Koffi Olomidé","Franco","Rosemary Njage","Alice Kamande","Alice Kamande","Geraldine Oduor","Rose Muhando","Jubilee Christian Church","Senzo","Eunice Njeri","Makena","Daddy Owen","Air","Angela Chibalonza Muliri","UB40","Jose Chameleone","Junior Kelly","Frorence Mureithi","Angela Chibalonza Muliri","H_art the Band","Lucky Dube","Mafikizolo","DJ Nation","Alicios","Elani","Alaine","Brenda Fassie","Sauti Sol","Morgan Heritage","Maxi Priest","Ambassadors of Christ Choir","Sanchez","Rose Muhando","Diamond","D'banj","Rose Muhando","Israel Vibration","Samba Mapangala & Orchestra Virunga","Tony Nyadundo","Morgan Heritage","Rose Muhando","Hellenah Ken","P-Square","Lady Isa","Gilad","Oliver ","Rose Muhando","Rémy Sahlomon","Madilu System","Sahlomon","Koffi Olomidé","Koffi Olomidé","Youssou N'Dour","Alain Kounkou","Christelle Ntesa Love","Franco","Them Mushrooms","Pépé Kallé","Sam Fan Thomas","Papa Wemba","Pallaso & Sheebah","Vicc Rage","Slaves","Stretford End Boys","Rickey Smiley","Habel Kifoto","Madilu System","Orchestre Les Wanyika","Fally ipupa","CG Bros","Mory Kanté","Bosco Mulwa Musyoka","Jahazi Modern Taarab","The Moipet Quartet","Jemmimah Thiong'o","Stella Mwangi","Nathaniel Bassey","Diamond","Numb3rz","Angela Chibalonza Muliri","Glen Washington","Mbilia Bel","Stylo G","Pst. Emmanuel Ushindi","Glen Washington","Alikiba","Suzanna Owiyo","Lady Jaydee","Alexandra Burke","Koffi Olomidé","Franco And The Dreadnought","Eric Donaldson","Christina Shusho","Samba Mapangala & Orchestra Virunga","Angélique Kidjo","DaVido","Marlaw","Diamond","Mbilia Bel","Papa Wemba","Franco","Samba Mapangala & Orchestra Virunga","Madilu System","Franco","Nayanka Bell","Solomon Mkubwa","Werrason","Aurlus Mabele","Mbaraka Mwinshehe","Wenge Musica BCBG","ferre Gola","Skata","Victoria Kimani","Fally ipupa","Redsan","Olamide","Papa Wemba","Vicious Vocal Sound Effects","Daddy Blue","Dennis Brown","Chezidek","Barry Issac","Judy Boucher","Burning Spear","J Capri","Apache Indian","South Hill Productions","Giannis Liolios","Patty Monroe & Bebe Cool","Professor","Yondo Syster","Kanda Bongo Man","Koffi Olomidé","Fally ipupa","Extra Musica","Emmanuel Musindi","Eswi Yo Wapi","Dully Sykes","Yemi Alade feat. Selebobo","Gidi Gidi Maji Maji","Radio & Weasel","Culture","Angela Chibalonza Muliri","Mercylinah","Michael W. Smith","Kijitonyama Upendo Group","Mary Nungari","Hellenah Ken","Rose Muhando","Tony Rebel","Children Of Gospel","Bob Marley & The Wailers","Bahati Bukuku","Joyous Celebration","Bahati","Madilu System","Gerry & The Pacemakers","Estudios Talkback","Solomon Mkubwa","Da Twins","SPE6FIK","Morgan Heritage","Mykal Rose","Michael Prophet","Ijahman Levi","Lucky Dube","Wailing Souls","Culture","Israel Vibration","Israel Vibration","Duane Stephenson","R-Kane Records","Culture","Don Carlos","Klan Destino","BOBBY CRYSTAL","Gregory Isaacs","Peter Hunnigale","Duane Stephenson","Perfect","Beres Hammond","Gregory Isaacs","Garnett Silk","Freddie Mcgregor","Inner Circle","Peter Andre","Anthony B","Frankie Paul","Beenie Man","Shabba Ranks","Yellowman","Chaka Demus & Pliers","Admiral Bailey","Ssgt Mutambo Music Council","Bigpin","Sauti Sol","Papa Wemba","Koffi Olomidé","Fally ipupa"]


;

function myFunction2() {
  
         let counts = arr.reduce((map, fruit) => {
              map[fruit] = (map[fruit] || 0) + 1;
              return map;
          }, {});
  
        let sorted = Object.keys(counts).sort((a, b) => counts[b] - counts[a]);
  
  let top5 = sorted.slice(0, 10000);

   

    for(i = 0; i < top5.length; i++) {
               {

              var f = top5[i];
              count = 0;
             
              var matched = f.match(art);

              if (matched)
               {

                document.getElementById("rank").innerHTML = i + 1;

              }

               

            }
        
       } 

   

}


