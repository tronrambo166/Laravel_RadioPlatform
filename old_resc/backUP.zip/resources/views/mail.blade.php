

        

<!--Hidden Cart view-->

        <div class="row  w-75 m-auto border shadow text-center bg-light" style=" box-shadow: 3px 3px 7px 7px grey; width:70%; margin:auto; broder:2px solid black; text-align:center">
		<div class="container w-75 m-auto" style="width:80%; margin:auto; text-align:center">
		<h1 class="font-weight-bold py-3" style=" padding-top:30px; padding-bottom:20px; font-weight:bold; text-align:center;" > Rewind Cloud Radio</h1>
		 <br />To reset password just follow the link below!</p>
		
		
				<a class="h5 btn btn-danger w-100  " href="http://muziqyrewind.com/forgot/{{$email}}" 
				style="text-decoration:none; border-radius:7px;  font-weight:bold; padding-top:15px; padding-bottom:15px; text-align:center; width:100%; background-color:aliceblue;"  >
				    
				<h1 style=" font-family:arial; border-radius:7px;  font-weight:bold; padding-top:15px; padding-bottom:15px; text-align:center; width:100%; background-color:aliceblue;
				 color:black; text-decoration:none; "  >RESET</h1></a>
				
				
				<p style=" color:black; line-height:22px; font-family:arial; padding-top:20px; padding-bottom:20px; text-align:center;" class="py-3 text-center"> All the best! <br /> Rewind Cloud Radio.</p>

		</div>
		
		
		</div>
  
        
		
       
      

<script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
       

<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
    


<!--Hidden Cart view-->


        

        
