@extends('layout') 
@section('page')



<div class="row mx-auto" style="width:90%; background:#161616;" >  
         <div class="col-md-12"> 
             <h4 class="text-center mt-2 text-light">Rewind Cloud Monitoring</h4> <hr> 

 <table class="shadow mb-3 w-100 bg-white table tabil">
  <thead>
    <tr class=" bg-dark w-100">
      
       <p class="text-left py-3 my-0  font-weight-bold text-success h5 pl-2">Top 10 in the region</p> 
      

      
      
    </tr>
  </thead>
  <tbody>
    <tr class="border">
   
    </tr>
    
  </tbody>
</table>

<div class="row ">

  <div class="col-sm-4">
     <p class="text-left py-3 my-0  font-weight-bold text-success h6 pl-2">Top 10 Tracks</p> 

          <table class="table tabil mb-4 text-white">
  <thead>
    <tr>
      <th scope="col">Position</th>
      <th scope="col">Title</th>
      <th scope="col">Album</th>
      <th scope="col">Duration</th>
     
    
    </tr>
  </thead>
  <tbody id="songs">  <?php $i=0;?>

  @if(isset($tracks))
   @foreach($tracks as $song) <?php  ?>
   @if($i<=10)
   

    <tr id="loading">
       <td scope="row" class="text-center"> {{ ++$i }} </td>
      <td scope="row" class="text-center"> {{ $song['song'] }} </td>
     <td scope="row" class="text-center"> {{ $song['album'] }} </td>
     <td scope="row" class="text-center"> {{ round($song['duration'])  }} sec</td>
       
         
    </tr>

   @endif
   @endforeach
   @endif


    
  </tbody>
</table>
  </div>

<div class="col-sm-1"></div>
  <div class="col-sm-5 pt-5 text-white">
    @if(isset($listeners))
    Monthly Listeners = {{$listeners}}
    @endif
  </div>

  <div class="col-sm-2">
    
  </div>

</div>

  

<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>

             </div>  

        
</div>



          @endsection
        
       

