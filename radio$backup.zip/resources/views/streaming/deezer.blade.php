@extends('layout') 
@section('page')



<div class="row mx-auto" style="width:90%; background:#161616;" >  
         <div class="col-md-12"> 
             <h4 class="text-center mt-2 text-light">Rewind Cloud Monitoring</h4> <hr> 

 <table class="shadow mb-3 w-100 bg-white table tabil">
  <thead>
    <tr class=" bg-dark w-100">
     <h3 class="text-center bg-light text-primary">DEEZER</h3>
       <p class="text-left py-3 my-0  font-weight-bold text-success h5 pl-2">Top 10 in the region</p> 
      

      
      
    </tr>
  </thead>
  <tbody>
    <tr class="border">
   
    </tr>
    
  </tbody>
</table>

<div class="row ">

  <div class="col-sm-5">
          <table class="table tabil mb-4 text-white">
  <thead>
    <tr>
      <th scope="col">Position</th>
      <th scope="col">Title</th>
      <th scope="col">Artist</th>
      <th scope="col">Album</th>
      <th scope="col">Duration</th>
    
    </tr>
  </thead>
  <tbody id="songs">  <?php $i=0;?>

  @if(isset($school))
   @foreach($school as $song) <?php $cnt=0;$k=0; ?>
   @if($i<=10)
   

    <tr id="loading">
       <td scope="row" class="text-center"> {{ ++$i }} </td>
      <td scope="row" class="text-center"> {{ $song[$k] }} </td>
      <td scope="row" class="text-center"> {{ $song[$k+1] }} </td>
       <td scope="row" class="text-center"> {{ $song[$k+2]}} </td>
        <td scope="row" class="text-center"> {{ $song [$k+3] }} </td>
         
    </tr>

   @endif
   @endforeach
   @endif


    
  </tbody>
</table>
  </div>

  <div class="col-sm-5 text-white">
    @if(isset($fan))
    DEEZER Fans = {{$fan}}
    @endif
  </div>

  <div class="col-sm-2">
    
  </div>

</div>

  

<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>

             </div>  

        
</div>



          @endsection
        
       

