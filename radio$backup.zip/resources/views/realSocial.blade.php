@extends('layout') 
@section('page')



<div class="row mx-auto" style="width:90%; background:#161616;" >  
         <div class="col-md-12"> 
             <h4 class="text-center mt-2 text-light">Rewind Cloud Monitoring</h4> <hr> 

       <table class="shadow mb-3 w-100  shadow border table tabil text-light" style="width:90%; background:#1e1e1e;">
  <thead>
    <tr class="  w-100">
       <p class="text-left py-3 my-0 bg-dark font-weight-bold text-success h5 pl-2">Artist Social</p> 

      
      <th> Facebook</th>
      <th> Intagram</th>
      <th> Twitter</th>
     
      
    </tr>
  </thead>
  <tbody>
    <tr class="border">
      
     
      <td>coming soon...</td>
      <td>coming soon...</td>
      <td>coming soon...</td>
    </tr>
    
  </tbody>
</table>

<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>

             </div>  

        
</div>



          @endsection
        
       

