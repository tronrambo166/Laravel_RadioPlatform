@extends('layout') 
@section('page')


 <h3 class="py-2 text-center text-light">About Us:</h3> <hr>

<div class="row mx-auto py-4 text-light" style="width:90%; background:#161616;">  
       
           
<p class="text-center justify-center">Monitor music airplay for radio stations. Know your by the minute Rank as per your music playing historically among others. Get to know your most popular songs. Get to know the Top 20 songs playing on Radio. Get a Breakdown of your music played in the past 5 days.
</p>
           
          
</div>


<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>

          @endsection
        
       

