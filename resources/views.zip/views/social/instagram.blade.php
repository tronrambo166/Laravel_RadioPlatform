@extends('layout') 
@section('page')


@php $data = Session::get('instaInfo'); @endphp
<div class=" mx-auto" style="width:95%; background:#161616;" >  
   <h4 class="text-center mt-2 text-light w-75">Instagram Report <a href="{{route('youtube')}}" class="float-right text-light rounded-0 mr-2 px-4 btn btn-outline-dark font-weight-bold my-1">Back</a>
   </h4> <hr>
   

         <div class="row"> 
            

<div class="col-sm-7 chart1">
<?php

 $dataPoints = array(
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[1]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[2]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[3]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[4]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[5]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
 
 );



 $dataPoints2 = array(
  array( "y" => $insta[0]['reach'], "label" => $insta[0]['date']),
  array( "y" => $insta[1]['reach'], "label" => $insta[0]['date']),
  array( "y" => $insta[2]['reach'], "label" => $insta[0]['date']),
  array( "y" => $insta[3]['reach'], "label" => $insta[0]['date']),
  array( "y" => $insta[4]['reach'], "label" => $insta[0]['date']),
  array( "y" => $insta[5]['reach'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
  array( "y" => $insta[0]['impressions'], "label" => $insta[0]['date']),
 
  
  
 );
 
 
?>

<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
  animationEnabled: true,
  theme: "light2",
  title:{
    text: "Monthly Gained Impressions @Realshinski"
  },
  axisX: {
    valueFormatString: "DD MMM"
  },
  axisY: {
    title: "Total Number of Views",
    includeZero: true,
    maximum: 1000
  },
  data: [{
    type: "spline",
    color: "#6599FF",
    xValueType: "dateTime",
    xValueFormatString: "DD MMM",
    yValueFormatString: "#,##0 Visits",
    dataPoints: <?php echo json_encode($dataPoints); ?>
  }]
});
 

 


//_______________________________________________________________________//

var chart2 = new CanvasJS.Chart("chartContainer2", {
  animationEnabled: true,
  theme: "light2",
  title:{
    text: "Monthly Gained Reach @Realshinski"
  },
  axisX: {
    valueFormatString: "DD MMM"
  },
  axisY: {
    title: "Total Number of Subscribers",
    includeZero: true,
    maximum: 5000
  },
  data: [{
    markerSize:7,
    type: "spline",
    color: "#6599FF",
    xValueType: "dateTime",
    xValueFormatString: "DD MMM",
    yValueFormatString: "#,##0 Subscribers",
    dataPoints: <?php echo json_encode($dataPoints2); ?>
  }]
});
chart.render();
chart2.render();
}
</script>


<div id="chartContainer" style="height: 320px; width: 100%;"></div>
<div id="chartContainer2" class="mt-2" style="height: 320px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</div>


        
 <div class="col-sm-5 chart2">

<table class="table tabil mb-4 text-white">
  <thead>
    <tr>
      <th scope="col">Date</th>
      <th scope="col">Subscribers</th>
      <th scope="col">Video Views</th>
       <th scope="col">Earnings</th>    
    
    </tr>
  </thead>

  <tbody class="bg-light text-dark" id="songs">  
   @for($i=0;$i<=30;$i++)
    <tr id="loading">
       <td scope="row" class="text-center">  </td>
      <td scope="row" class="text-center">  </td>
      <td scope="row" class="text-center">  </td>
      <td scope="row" class="text-center">  </td>
               
    </tr>
    @endfor
  </tbody>

</table>


</div>

         </div>  


  

<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>
<div style="width:90%; background:#161616;" class=" mx-auto py-5"></div>


        
</div>



          @endsection
        
       
