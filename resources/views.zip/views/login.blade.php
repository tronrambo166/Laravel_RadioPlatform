@extends('UserPages.layout')  
@section('content')
       



<div class="row " >  <h2 class="px-4 w-100 d-block py-4 text-center"> <span class="text-danger">Rewind</span> to Know Your Playback</h2> </div> <p id="rank"></p> 

<div class="row " >  
         <div class="col-md-3"> 
            

             </div>  

         <div class="col-md-3"> </div>
           <div class="col-md-6 text-center">
             

             <img src="images/image.jpg" class="img-fluid" height="500px">

           </div>    
          
</div>
</div>

@endsection
